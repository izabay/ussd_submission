<footer style="text-align:center;">
    <p>&copy; <?php echo date("Y"); ?> Offering system. All rights reserved.</p>
</footer>

<?php

// Prompt user for input
echo "Enter your name: ";

// Read input from the command line
$name = readline();

// Display the input
echo "Hello, " . $name;

?>
